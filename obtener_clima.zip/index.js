// Enriquecimiento de datos


// Requeridos
const gps = require('gps2zip'); 
const weather = require('weather-js'); 

// Obtencion del clima en base a la ubicación del sensor
exports.handler = function handler(event, context, callback) {
    
    // Obtener CP en base a la latitud y longitud
    var zipLookupResponse = gps.gps2zip(event[0].latitude, event[0].longitude);
    
    // Obtener Clima en base al CP
    weather.find({search: zipLookupResponse.zip_code, degreeType: 'C'}, function(err, result) {
        // Si hay error
        if(err) {
            console.log(err);
            callback(err);
        }
        
        // Se agregan el clima y el CP al payload del msj MQTT
        event[0].weather = result[0].current.skytext;
        event[0].zipcode = zipLookupResponse.zip_code;
        
           
        callback(null, event);
    });
};
